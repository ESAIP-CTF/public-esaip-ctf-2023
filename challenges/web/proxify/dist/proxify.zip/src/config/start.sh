node /usr/app/app.js &
nginx -g "daemon off;"